Hello World
=================================

This is a simple echo example, used to respond to a sent message with a
modified version of the request message being returned in a response.

To deploy the example, please read the RiftSaw project document for installing
a RiftSaw into JBoss AS 5.1 or higher version and read the JBoss BPEL editor 
project document for deploying this example into the JBoss BPEL runtime .

To test the example, for example using the WTP test tool, 
1 Right-click on the example "bpel/HelloGoodbye.wsdl", click  on "Web Services
  > Test with Web Services Explorer" to open the web service explorer.
2 Click the link "hello". In the new page input "Message"= Hello, 
  Click on the "Go" button. You will get the respond of the bpel process: 
  'Hello World' in the "Status" section.
