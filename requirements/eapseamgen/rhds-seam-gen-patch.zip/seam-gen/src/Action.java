package @actionPackage@;

import javax.ejb.Local;

@Local
public interface @interfaceName@ {  
    
	//seam-gen method
	public void @methodName@();  
	
    //add additional interface methods here
}