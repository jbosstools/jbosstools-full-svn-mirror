Simple Correlation
========================================

This example builds on another 'hello_world' example, to show a
simple example of how two separate interactions can be correlated to the
same BPEL process instance.

In this case, a 'hello' message must be sent first, and then a 'goodbye'
message must follow, where both messages must have the same ID field to
enable them to be correlated to the same process instance.

To deploy the example, please read the RiftSaw project document for installing
a RiftSaw into JBoss AS 5.1 or higher version and read the JBoss BPEL editor 
project document for deploying this example into the JBoss BPEL runtime .

To test the example, for example using the WTP test tool, 
1 Right-click on the example "bpel/HelloGoodbye.wsdl", click  on "Web Services
  > Test with Web Services Explorer" to open the web service explorer.
2 Click the link "hello". In the new page input "id"=1 and "Message"= Hello, 
  Click on the "Go" button. You will get the respond of the bpel process: 
  'Hello World' in the "Status" section.
3 Click the link "goodbye". In the new page input "id"=1 and "Message"= Goodbye, 
  Click on the "Go" button. You will get the respond of the bpel process: 
  'Goodbye World' in the "Status" section.  